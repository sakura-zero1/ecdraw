# 连线模式态编辑交互优化

## Context

当前连线模式下，点击已连线后需要：选中连线 → 查看形状标签列表 → 点击标签 → 弹出属性面板，交互步骤过多且 UI 不够美观（含调试代码）。用户希望简化为：点击连线 → 直接进入态编辑模式，隐藏引脚/连线，在闭合态/断开态间切换预览，像绘图模式一样直接拖动/修改关联形状的覆盖属性，用顶部 ShapeToolbar 调整颜色等。

## 涉及文件

| 文件 | 改动 |
|------|------|
| `src/stores/useCanvasStore.ts` | 新增 `wireStateEditing` 状态及相关 actions |
| `src/components/canvas/ComponentCanvas.tsx` | 核心改动：删除调试代码、重写工具栏、重构连线模式鼠标事件、修改渲染逻辑、删除旧属性编辑器 |
| `src/components/canvas/ShapeToolbar.tsx` | 态编辑模式下颜色/线宽写入覆盖属性 |

## 步骤

### 1. 删除调试代码 (ComponentCanvas.tsx)

删除以下位置：
- L1221: `console.log('[wire-mode] connHit:...')`
- L1225: `console.log('[wire-mode] selectedConnection:...')`
- L2076-2080: DEBUG 蓝色方块 (`// DEBUG: verify wire mode renders` 及 `ctx.fillStyle = 'rgba(59,130,246,0.15)'; ctx.fillRect(...)`)
- L2098: `console.log('[wire-render] selectedConnectionId:...')`
- L2101: `console.log('[wire-render] selConn:...')`
- L2105: `console.log('[wire-render] pinA:... pinB:...')`
- L2109: `console.log('[wire-render] toolbar center:...')`
- L2141-2149: 红色 DEBUG 背景 (`// Floating toolbar - DEBUG:` 及 `ctx.fillStyle = 'red'; ctx.fillRect(...)`)
- L2151: 注释 `// 闭合态 button` → 保留逻辑，仅删 DEBUG 注释

### 2. 新增 Canvas Store 状态 (useCanvasStore.ts)

新增字段和 actions：

```typescript
wireStateEditing: boolean;  // 是否处于态编辑预览模式
enterWireStateEditing: () => void;
exitWireStateEditing: () => void;
```

- `enterWireStateEditing`: 设置 `wireStateEditing = true`，设置 `wireEditState = 'closed'`（默认闭合态）
- `exitWireStateEditing`: 设置 `wireStateEditing = false`，清除 `selectedConnectionId`、`wireEditState`、`wireEditingShapeId`、`selectedShapeIds`
- 修改 `setActiveTool`: 退出 wire 模式时也调用 `exitWireStateEditing` 逻辑
- 删除 `wireEditingShapeId` 相关逻辑（不再需要单独的"正在编辑属性的形状"概念，直接用 `selectedShapeIds` 即可）

### 3. 修改 resolveShapeProps (ComponentCanvas.tsx L264-273)

新增第四个可选参数 `previewState`：

```typescript
function resolveShapeProps(
  el: ShapeElement,
  matrices: Record<string, ConnectivityMatrix>,
  compId: string,
  previewState?: { connectionId: string; state: 'closed' | 'open' } | null,
): ShapeElement
```

当 `previewState` 存在且 `el.linkedConnectionId === previewState.connectionId` 时，使用 `previewState.state` 决定覆盖，否则保持原逻辑。

### 4. 修改渲染逻辑 (ComponentCanvas.tsx useEffect 渲染回调)

**4a. 形状渲染**：传入 `previewState`
```
const previewState = wireStateEditing && selectedConnectionId
  ? { connectionId: selectedConnectionId, state: wireEditState }
  : null;
// resolveShapeProps 调用均传入 previewState
```

**4b. 引脚/连线隐藏**：`wireStateEditing` 为 true 时跳过引脚和连线绘制。

**4c. 关联形状高亮**：态编辑模式下，对 `linkedConnectionId === selectedConnectionId` 的形状绘制蓝色虚线选框和拖动手柄（复用现有选中逻辑）。

**4d. 连线拖线隐藏**：`wireStateEditing` 时跳过 wireFromRef 的橡皮线绘制。

### 5. 重写浮动工具栏 (ComponentCanvas.tsx)

删除旧的红色 DEBUG 工具栏、形状标签列表、旧属性编辑器调用。

**新工具栏布局**（世界坐标系，全部除以 zoom）：
```
┌─────────────────────────────────────────────────┐
│  [闭合态]  [断开态]              [💾保存]  [×]   │
└─────────────────────────────────────────────────┘
```

- 背景：白色 `#ffffff`，圆角 `10/zoom`，柔和阴影 `rgba(0,0,0,0.1)` blur `12/zoom`
- 总宽：`220/zoom`，高：`40/zoom`
- 闭合态按钮：选中时绿调 `#dcfce7` / `#15803d`，左边框 `3/zoom` 宽 `#10b981`
- 断开态按钮：选中时橙调 `#fff7ed` / `#c2410c`，左边框 `3/zoom` 宽 `#f97316`
- 保存按钮：蓝调 `#eff6ff` / `#1d4ed8`，带 💾 图标文字
- 关闭按钮：右侧圆形 `#f1f5f9` 底，`×` 符号 `#64748b`

用 `wireToolbarRectsRef` 存储按钮碰撞区域用于点击检测。

### 6. 重构鼠标事件处理 (ComponentCanvas.tsx handleMouseDown)

连线模式分支重构为两个子模式：

**6a. 非态编辑模式（原有）**：
- 点击引脚 → 开始拖线（不变）
- 点击连线 → `selectConnection(connId)` + `enterWireStateEditing()`
- 其他 → 原有逻辑

**6b. 态编辑模式（新增）**：
- 工具栏按钮点击 → 处理闭合态/断开态/保存/关闭
- 关联形状点击 → `selectShape(shapeId)` → 显示选中框和手柄
- 关联形状拖动 → 复用现有 `dragState` 机制，但最终写入 `stateClosed`/`stateOpen` 覆盖属性
- 关联形状手柄拖动 → 复用现有 resize 逻辑，但写入覆盖属性
- 非关联形状点击 → 关联到当前连线（`updateShapeElement(linkedConnectionId)`）
- 空白点击 → 取消形状选择（保持态编辑模式）

### 7. 修改 handleMouseMove 支持态编辑拖动

在 `dragState.type === 'shape'` 和 `'handle'` 分支中，判断 `wireStateEditing`：

- **正常模式**：`updateShapeElement(compId, shapeId, { x, y, ... })` — 写基础属性
- **态编辑模式**：`updateShapeElement(compId, shapeId, { stateClosed: { ...existingOv, x, y, ... } })` — 写覆盖属性

覆盖属性的 key 由 `wireEditState` 决定（`'closed'` → `stateClosed`，`'open'` → `stateOpen`）。

### 8. 修改 ShapeToolbar.tsx

新增订阅 `wireStateEditing` 和 `wireEditState`：

- `applyToSelected` 在态编辑模式下改为写入覆盖属性：
  ```typescript
  const ovKey = wireEditState === 'closed' ? 'stateClosed' : 'stateOpen';
  updateShapeElement(activeComponentId, sid, {
    [ovKey]: { ...(shape[ovKey] ?? {}), ...updates }
  });
  ```
- 颜色显示读取覆盖后的值（如 `shape.stateClosed?.fill ?? shape.fill`）
- 态编辑模式下禁用组合/解组/旋转/翻转/删除按钮（避免误操作）

### 9. 删除旧属性编辑器代码 (ComponentCanvas.tsx)

删除以下不再使用的函数和常量：
- `drawPropertyEditor` (L450-587)
- `hitTestPropertyEditor` (L292-406)
- `drawNumField` (L408-448)
- `COLOR_PALETTE` (L281-284) — 确认仅被属性编辑器使用后删除
- `wireTagRectsRef` 相关逻辑

## 验证

1. `pnpm tauri dev` 启动应用
2. 创建/打开一个元件，添加多个形状和引脚
3. 进入连线模式 (W)，从一个引脚拖到另一个引脚创建连线
4. 点击连线 → 工具栏出现，引脚和连线消失
5. 点击闭合态/断开态切换预览
6. 点击关联形状，拖动/调整大小
7. 使用顶部 ShapeToolbar 修改颜色/线宽
8. 点击保存按钮确认
9. 点击 × 关闭 → 引脚/连线恢复显示
10. `Ctrl+Z` 撤销测试
11. 验证输出预览区域的连线态显示正确
